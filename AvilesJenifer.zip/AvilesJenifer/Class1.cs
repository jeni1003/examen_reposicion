﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Libreria para trabajar con BD
using System.Data;
using System.Data.SqlClient; //Libreria para conectarse una BD de SQL Server

namespace AvilesJenifer
{
    class Conexion_db
    {

        class Conexion_db
        {
            SqlConnection miConexion = new SqlConnection();
            SqlCommand comandosSQL = new SqlCommand();
            SqlDataAdapter miAdaptadorDatos = new SqlDataAdapter();

            DataSet ds = new DataSet();

            public Conexion_db()
            {
                String cadena = @"Data Source=DESKTOP-GPDU8II\SQLEXPRESS;Initial Catalog=db_parqueo_vehicular_aviles_jenifer;Integrated Security=True";
                miConexion.ConnectionString = cadena;
                miConexion.Open();

                //inicializar los parametros que se van en las consultas
                parametrizacion();
            }
            private void parametrizacion()
            {
                comandosSQL.Parameters.Add("@id", SqlDbType.Int).Value = 0;
                comandosSQL.Parameters.Add("@marca", SqlDbType.Char).Value = "";
                comandosSQL.Parameters.Add("@modelo", SqlDbType.Char).Value = "";
                comandosSQL.Parameters.Add("@año", SqlDbType.Int).Value = 0;

            }

            public DataSet obtener_datos()
            {
                ds.Clear();
                comandosSQL.Connection = miConexion;

                comandosSQL.CommandText = "select * from tbl_vehiculo";
                miAdaptadorDatos.SelectCommand = comandosSQL;
                miAdaptadorDatos.Fill(ds, "tbl_vehiculo");

                return ds;
            }
            public void mantenimiento_datos(String[] datos, String accion)
            {
                String sql = "";
                if (accion == "nuevo")
                {
                    sql = "INSERT INTO tbl_vehiculo (marca,modelo,año) VALUES(@marca,@modelo,@año)";
                }
                else if (accion == "modificar")
                {
                    sql = "UPDATE tbl_vehiculo SET " +
                        "marca         = @marca," +
                        "modelo        = @modelo," +
                        "año           = @año," +
                        "WHERE idvehiculo = @id";
                }
                else if (accion == "eliminar")
                {
                    sql = "DELETE tbl_vehiculo FROM tbl_vehiculo WHERE idvehiculo=@id";
                }
                comandosSQL.Parameters["@id"].Value = datos[0];
                if (accion != "eliminar")
                {
                    comandosSQL.Parameters["@marca"].Value = datos[1];
                    comandosSQL.Parameters["@modelo"].Value = datos[2];
                    comandosSQL.Parameters["@año"].Value = datos[3];

                }
                procesarSQL(sql);
            }

            void procesarSQL(String sql)
            {
                comandosSQL.Connection = miConexion;
                comandosSQL.CommandText = sql;
                comandosSQL.ExecuteNonQuery();
            }

        }
    }
}


