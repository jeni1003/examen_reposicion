﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AvilesJenifer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (btnagregar.Text == "Nuevo")
            {//nuevo
                btnagregar.Text = "Guardar";
                btnmodificar.Text = "Cancelar";

                habdes_controles(false);//habilitar los controles...
            }
            else
            {//guardar
                _idvehiculo = int.Parse(id.Text);
                this.Validate();

                /**
                 * Abrimos la conexion a la BD
                 */
                //ventasTableAdapter.Connection.Open();
                SqlCommand sqlCmd = new SqlCommand();
                //sqlCmd.Connection = ventasTableAdapter.Connection;

                if (_idvehiculo > 0)
                {//modificando...
                    sqlCmd.CommandText = "delete from tbl_vehiculo where idvehiculo=" + _idvehiculo;
                    sqlCmd.ExecuteNonQuery();
                }
                else
                {//nuevo....
                    sqlCmd.CommandText = "select ident_current('vehiculo') + 1 AS idvehiculo";
                    _idvehiculo = int.Parse(sqlCmd.ExecuteScalar().ToString());
                }
                int nfilas = dataGridView1.RowCount;
                string[,] dvehiculo = new string[nfilas, 4];
                DataGridViewRow fila = new DataGridViewRow();
                for (int i = 0; i < nfilas; i++)
                {
                    fila = dataGridView1.Rows[i];

                    dvehiculo[i, 0] = fila.Cells["idvehiculo"].Value.ToString();
                    dvehiculo[i, 1] = fila.Cells["marca"].Value.ToString();
                    dvehiculo[i, 2] = fila.Cells["modelo"].Value.ToString();
                    dvehiculo[i, 3] = fila.Cells["año"].Value.ToString();
                }
                this.tableAdapterManager.UpdateAll(this.db_parqueo_vehicular_aviles_jeniferDataSet1);


                tbl_vehiculoTableAdapter.Connection.Close();

                habdes_controles(true);
                btnagregar.Text = "Nuevo";
                btnmodificar.Text = "Modificar";
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'db_parqueo_vehicular_aviles_jeniferDataSet.tbl_vehiculo1' Puede moverla o quitarla según sea necesario.
            this.tbl_vehiculo1TableAdapter.Fillvehiculo(this.db_parqueo_vehicular_aviles_jeniferDataSet.tbl_vehiculo1);

        }
    }
    }
}
