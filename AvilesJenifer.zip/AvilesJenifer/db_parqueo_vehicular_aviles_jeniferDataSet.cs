﻿namespace AvilesJenifer
{


    partial class db_parqueo_vehicular_aviles_jeniferDataSet
    {
    }
}
